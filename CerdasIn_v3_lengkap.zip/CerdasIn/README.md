# CerdasIn — siap deploy

## Jalankan di komputer
1. Install Node.js 18+.
2. Buka folder ini di Terminal.
3. Jalankan `npm start`.
4. Buka `http://localhost:3000`.

## Deploy
Upload seluruh folder proyek ke hosting yang mendukung Node.js, lalu jalankan `npm start` atau gunakan start command `node server.js`.

## Catatan
- Bank soal terpisah untuk Mapel dan Tes IQ.
- 248 soal awal; soal diacak dan difilter berdasarkan jenjang, mapel, dan kesulitan.
- Latihan tidak masuk ranking.
- Kompetisi dan Tes IQ dapat masuk ranking.
- Ranking server-side, top 10, dan cooldown 2 hari untuk kombinasi percobaan yang sama.
- Email yang disimpan di ranking ditampilkan dalam bentuk tersamarkan.
- Login Google/OAuth dan AI model sungguhan memerlukan kredensial/layanan eksternal dan belum diaktifkan otomatis.
